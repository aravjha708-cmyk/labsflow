-- =========================================================
-- FLOW LABS — SUPABASE DATABASE SCHEMA & RLS POLICIES
-- Paste this script into your Supabase SQL Editor
-- =========================================================

-- Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 0. APP SETTINGS TABLE
CREATE TABLE IF NOT EXISTS public.app_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  is_updating_accounts BOOLEAN DEFAULT FALSE,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
-- Insert default row if none exists
INSERT INTO public.app_settings (is_updating_accounts)
SELECT FALSE WHERE NOT EXISTS (SELECT 1 FROM public.app_settings);

-- 1. POOL COOKIES TABLE (Created first so other tables can reference it)
CREATE TABLE IF NOT EXISTS public.pool_cookies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  provider_name TEXT NOT NULL DEFAULT 'Google Veo/Flow Master Pool',
  cookie_data TEXT NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  account_email TEXT,
  last_verified TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  lab_id TEXT, -- Removing UNIQUE to allow multiple profiles per lab_id
  role TEXT NOT NULL CHECK (role IN ('admin', 'reseller', 'user')) DEFAULT 'user',
  plan TEXT NOT NULL DEFAULT 'none',
  expires_at TIMESTAMPTZ,
  created_by_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  assigned_cookie_id UUID REFERENCES public.pool_cookies(id) ON DELETE SET NULL,
  quota_limit INT DEFAULT 50,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Migration columns for existing database
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS name TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS lab_id TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS assigned_cookie_id UUID REFERENCES public.pool_cookies(id) ON DELETE SET NULL;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS account_password TEXT;

-- 3. TRIAL CODES TABLE
CREATE TABLE IF NOT EXISTS public.trial_codes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  duration_hours INT NOT NULL DEFAULT 2,
  is_used BOOLEAN DEFAULT FALSE,
  used_by_device TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. CLAIMED ACCOUNTS TABLE (Preserves Device Fingerprint permanently across profile deletions)
CREATE TABLE IF NOT EXISTS public.claimed_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  device_identifier TEXT UNIQUE NOT NULL,
  ip_address TEXT DEFAULT '127.0.0.1',
  profile_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  trial_code TEXT,  -- plain TEXT, no FK to allow any code string
  claimed_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. SYSTEM SETTINGS TABLE
CREATE TABLE IF NOT EXISTS public.system_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. GENERATION HISTORY TABLE
CREATE TABLE IF NOT EXISTS public.generation_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  prompt TEXT NOT NULL,
  model TEXT DEFAULT 'Veo 2 Ultra',
  aspect_ratio TEXT DEFAULT '16:9',
  status TEXT CHECK (status IN ('queued', 'processing', 'completed', 'failed')) DEFAULT 'completed',
  video_url TEXT,
  provider_used TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. PARTNER BRANDING TABLE
CREATE TABLE IF NOT EXISTS public.partner_branding (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reseller_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  brand_name TEXT NOT NULL DEFAULT 'Flow Studio',
  logo_url TEXT,
  primary_color TEXT DEFAULT '#1a73e8',
  support_url TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. EXTENSION SETTINGS TABLE
CREATE TABLE IF NOT EXISTS public.extension_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  latest_version TEXT NOT NULL DEFAULT '1.4.0',
  min_required_version TEXT NOT NULL DEFAULT '1.2.0',
  download_url TEXT NOT NULL DEFAULT 'https://flowlabs.ai/extension/download',
  release_notes TEXT DEFAULT 'v1.4.0: Improved Google Veo session sync stability.',
  force_update BOOLEAN DEFAULT FALSE,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. DEDICATED LAB USERS TABLE
CREATE TABLE IF NOT EXISTS public.lab_users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  lab_id TEXT UNIQUE NOT NULL,
  device_identifier TEXT NOT NULL,
  plan TEXT NOT NULL DEFAULT 'none',
  status TEXT NOT NULL DEFAULT 'pending',
  assigned_cookie_id UUID REFERENCES public.pool_cookies(id) ON DELETE SET NULL,
  assigned_email TEXT,
  assigned_cookie_data TEXT,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =========================================================
-- INITIAL SEED DATA
-- =========================================================

-- Seed Master Trial Codes
INSERT INTO public.trial_codes (code, duration_hours, is_used)
VALUES 
  ('FLOW2026', 2, false),
  ('ULTRAFREE', 2, false),
  ('VEOFLOW', 2, false)
ON CONFLICT (code) DO NOTHING;

-- Seed Initial Pool Cookies (Real seeded node credentials)
INSERT INTO public.pool_cookies (provider_name, cookie_data, is_active, account_email)
VALUES
  ('Google Veo 2 Master Pool A', '__SECURE_1PSID=AlphaNode001_VeoUltra2026', true, 'veo.node01.flowlabs@gmail.com'),
  ('Flow Ultra 4K Cluster B', '__SECURE_1PSID=BetaNode002_UltraFlow4K', true, 'veo.node02.flowlabs@gmail.com')
ON CONFLICT DO NOTHING;

-- Seed System Settings
INSERT INTO public.system_settings (key, value)
VALUES
  ('master_sync', '{"master_url": "https://api.flowlabs.internal/sync", "api_key": "fl_master_sync_key_998123"}'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- Seed Extension Settings
INSERT INTO public.extension_settings (id, latest_version, min_required_version, download_url, release_notes)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  '1.4.0',
  '1.2.0',
  'https://flowlabs.ai/extension/download',
  'Performance updates & provider session stability fixes.'
) ON CONFLICT (id) DO NOTHING;

-- =========================================================
-- ENABLE ROW LEVEL SECURITY (RLS) & PUBLIC ACCESS
-- =========================================================

ALTER TABLE public.pool_cookies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trial_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.claimed_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generation_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partner_branding ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.extension_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lab_users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read on trial_codes" ON public.trial_codes;
CREATE POLICY "Allow public read on trial_codes" ON public.trial_codes FOR SELECT USING (true);

DROP POLICY IF EXISTS "Allow public read/write on profiles" ON public.profiles;
CREATE POLICY "Allow public read/write on profiles" ON public.profiles FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public read/write on claimed_accounts" ON public.claimed_accounts;
CREATE POLICY "Allow public read/write on claimed_accounts" ON public.claimed_accounts FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public read/write on pool_cookies" ON public.pool_cookies;
CREATE POLICY "Allow public read/write on pool_cookies" ON public.pool_cookies FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public read/write on generation_history" ON public.generation_history;
CREATE POLICY "Allow public read/write on generation_history" ON public.generation_history FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public read/write on partner_branding" ON public.partner_branding;
CREATE POLICY "Allow public read/write on partner_branding" ON public.partner_branding FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public read/write on extension_settings" ON public.extension_settings;
CREATE POLICY "Allow public read/write on extension_settings" ON public.extension_settings FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public read/write on system_settings" ON public.system_settings;
CREATE POLICY "Allow public read/write on system_settings" ON public.system_settings FOR ALL USING (true);

DROP POLICY IF EXISTS "Allow public read/write on lab_users" ON public.lab_users;
CREATE POLICY "Allow public read/write on lab_users" ON public.lab_users FOR ALL USING (true);
